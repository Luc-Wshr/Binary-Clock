/*
 * File:   Clock.c
 * Author: LucWe
 *
 * Created on 30. November 2021, 21:31
 */

//-------   CLOCK.C ---------------
#include <xc.h>
#include <pic18.h>

void Wait (unsigned int DATA)
{
    unsigned int i, j;
    for (i=0; i<DATA; i++){
        for (j=0; j<1000; j++);
    }
}

void main(void) {

    unsigned char SEC, MIN, HR;
    
    TRISA = 0;
    TRISB = 0;
    TRISC = 0;
    TRISD = 0;
    TRISE = 0;
    ADCON1 = 0x0F;
    SEC = 0;
    MIN = 0;
    HR = 0;
    
    while(1) {
        SEC = SEC+1;
        if(SEC > 59){
            SEC = 0;
            MIN = MIN+1;
        }
    if (MIN > 59) {
        MIN = 0;
        HR = HR + 1;
    }
    
    if (HR>12) HR=1;
    
    PORTD = SEC;
    PORTC = MIN;
    PORTB = HR;
    
    Wait(1000);
        }
    }
