# Binary-Clock
Binary Clock + USART output for Systemnahe Programmierung
